package Classes;

public class Path {	
//	public static String indexSearchResult="/Users/simiao/Documents/workspace/IR_finalproject/WebContent/WEB-INF/data/index_search_result";	
//	public static String StopwordDir="/Users/simiao/Documents/workspace/IR_finalproject/WebContent/WEB-INF/stopword.txt";//address of stopwords.txt
//	public static String resultPath="/Users/simiao/Documents/workspace/IR_finalproject/WebContent/WEB-INF/data/abde.txt";
//	public static String processedPath="/Users/simiao/Documents/workspace/IR_finalproject/WebContent/WEB-INF/data/processed_search_result.txt";
//    public static String TopicDir="/Users/simiao/Documents/workspace/IR_finalproject/WebContent/WEB-INF/data/topics.txt";
//    public static String Top10="/Users/simiao/Documents/workspace/IR_finalproject/WebContent/WEB-INF/data/top10.txt";
	public static String indexSearchResult="//Users//simiao//Documents//workspace//IR_finalproject//WebContent//WEB-INF//data//index_search_result";	
	public static String StopwordDir="//Users//simiao//Documents//workspace//IR_finalproject//WebContent//WEB-INF//stopword.txt";////address of stopwords.txt
	public static String resultPath="//Users//simiao//Documents//workspace//IR_finalproject//WebContent//WEB-INF//data//abde.txt";
	public static String processedPath="//Users//simiao//Documents//workspace//IR_finalproject//WebContent//WEB-INF//data//processed_search_result.txt";
    public static String TopicDir="//Users//simiao//Documents//workspace//IR_finalproject//WebContent//WEB-INF//data//topics.txt";
    public static String Top10="//Users//simiao//Documents//workspace//IR_finalproject//WebContent//WEB-INF//data//top10.txt";
    public static String dataPath = "/Users/simiao/Documents/workspace/IR_finalproject/WebContent/WEB-INF/data";
}
