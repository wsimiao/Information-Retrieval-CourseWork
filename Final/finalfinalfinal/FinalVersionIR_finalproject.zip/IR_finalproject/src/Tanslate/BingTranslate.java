package Tanslate;

public class BingTranslate {

}
