package Interface;

public class testMethod {
	public String getSomeString(){
		String result = "this it is";
		return result;
	}

}
