package Interface;

public class Parameter {
	private String searchValue;
	public String getValue(){
		return this.searchValue;
	}
	public void setSearchValue(String searchValue){
		this.searchValue = searchValue;
	}
}
